'use client';

import React from 'react';

export function SEOKeywordTargeting() {
  return null;
}

export default SEOKeywordTargeting;
